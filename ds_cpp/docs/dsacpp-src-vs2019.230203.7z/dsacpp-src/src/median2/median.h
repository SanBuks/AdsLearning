/******************************************************************************************
 * Data Structures in C++
 * ISBN: 7-302-33064-6 & 7-302-33065-3 & 7-302-29652-2 & 7-302-26883-3
 * Junhui DENG, deng@tsinghua.edu.cn
 * Computer Science & Technology, Tsinghua University
 * Copyright (c) 2003-2023. All rights reserved.
 ******************************************************************************************/

#pragma once

template <typename T> //����S1[lo1, lo1 + n1)��S2[lo2, lo2 + n2)�ֱ���������������ظ�
T median ( Vector<T>& S1, Rank lo1, Rank n1, Vector<T>& S2, Rank lo2, Rank n2 ) { //��λ���㷨
   if ( n1 > n2 ) return median( S2, lo2, n2, S1, lo1, n1 ); //ȷ��n1 <= n2
   /*DSA*/ for ( Rank i = 0; i < lo1; i++ ) printf( "    ." ); for ( Rank i = 0; i < n1; i++ ) print( S1[lo1 + i] ); for ( Rank i = lo1 + n1; i < S1.size(); i++ ) printf( "    ." ); printf( "\n" );
   /*DSA*/ for ( Rank i = 0; i < lo2; i++ ) printf( "    ." ); for ( Rank i = 0; i < n2; i++ ) print( S2[lo2 + i] ); for ( Rank i = lo2 + n2; i < S2.size(); i++ ) printf( "    ." ); printf( "\n--\n\n" );
   if ( n2 < 6 ) //�ݹ����1 <= n1 <= n2 <= 5
      return trivialMedian( S1, lo1, n1, S2, lo2, n2 );
   ///////////////////////////////////////////////////////////////////////
   //                lo1            lo1 + n1/2      lo1 + n1 - 1
   //                 |                 |                 |
   //                 X >>>>>>>>>>>>>>> X >>>>>>>>>>>>>>> X
   // Y .. trimmed .. Y >>>>>>>>>>>>>>> Y >>>>>>>>>>>>>>> Y .. trimmed .. Y
   // |               |                 |                 |               |
   // lo2     lo2 + (n2-n1)/2       lo2 + n2/2     lo2 + (n2+n1)/2    lo2 + n2 -1
   ///////////////////////////////////////////////////////////////////////
   if ( 2 * n1 < n2 ) //�����������ĳ���������⣬���ߣ�S2����������ֱ�ӽس�
      return median( S1, lo1, n1, S2, lo2 + ( n2 - n1 - 1 ) / 2, n1 + 2 - ( n2 - n1 ) % 2 );
   ///////////////////////////////////////////////////////////////////////
   //    lo1                  lo1 + n1/2              lo1 + n1 - 1
   //     |                       |                       |
   //     X >>>>>>>>>>>>>>>>>>>>> X >>>>>>>>>>>>>>>>>>>>> X
   //                             |
   //                            m1
   ///////////////////////////////////////////////////////////////////////
   //                            mi2b
   //                             |
   // lo2 + n2 - 1         lo2 + n2 - 1 - n1/2
   //     |                       |
   //     Y <<<<<<<<<<<<<<<<<<<<< Y ...
   //                                .
   //                               .
   //                              .
   //                             .
   //                            .
   //                           .
   //                          .
   //                         ... Y <<<<<<<<<<<<<<<<<<<<< Y
   //                             |                       |
   //                       lo2 + (n1-1)/2               lo2
   //                             |
   //                            mi2a
   ///////////////////////////////////////////////////////////////////////
   Rank mi1 = lo1 + n1 / 2;
   Rank mi2a = lo2 + ( n1 - 1 ) / 2;
   Rank mi2b = lo2 + n2 - 1 - n1 / 2;
   if ( S1[mi1] > S2[mi2b] ) //ȡS1��롢S2�Ұ�
      return median( S1, lo1, n1 / 2 + 1, S2, mi2a, n2 - ( n1 - 1 ) / 2 );
   else if ( S1[mi1] < S2[mi2a] ) //ȡS1�Ұ롢S2���
      return median( S1, mi1, ( n1 + 1 ) / 2, S2, lo2, n2 - n1 / 2 );
   else //S1������S2����ͬʱ����
      return median( S1, lo1, n1, S2, mi2a, n2 - ( n1 - 1 ) / 2 * 2 );
}
